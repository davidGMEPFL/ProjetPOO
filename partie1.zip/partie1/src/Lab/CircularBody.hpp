#pragma once

class CircularBody
{


};

	
