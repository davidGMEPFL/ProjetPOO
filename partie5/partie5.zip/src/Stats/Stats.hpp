#pragma once


class Stats 
{
	// CLASSE A CODER
};

