#include "Bacterium.hpp"

Bacterium::Bacterium()
{

}
