#pragma once

class Bacterium
{
public:
    Bacterium();
};
